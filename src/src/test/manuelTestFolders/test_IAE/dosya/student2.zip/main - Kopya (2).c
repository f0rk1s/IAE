
#include <stdio.h>

int main()
{
 
    // prints hello world
    printf("Hello World");
	
 
    return 0;
}